package com.example.muhammad.easytour.ActivityOthersIntent;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.muhammad.easytour.ActivityRegistrationLogin.LoginActivity;
import com.example.muhammad.easytour.MainActivity;
import com.example.muhammad.easytour.R;
import com.example.muhammad.easytour.Weather.Api.RetrofitClient;
import com.example.muhammad.easytour.Weather.Api.WeatherApi;
import com.example.muhammad.easytour.Weather.CurrentResponse.CurrentWeather;
import com.example.muhammad.easytour.Weather.ForecastResponse.ForecastWeather;
import com.example.muhammad.easytour.Weather.Fragments.CurrentWeatherFragment;
import com.example.muhammad.easytour.Weather.Fragments.ForecastWeatherFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.muhammad.easytour.MainActivity.location;
import static com.example.muhammad.easytour.MainActivity.tabindex;
import static com.example.muhammad.easytour.Weather.Fragments.CurrentWeatherFragment.API_KEY;

public class WeatherActivity extends AppCompatActivity {

    private boolean isSignIn = false;
    private boolean isSignout = false;
    private boolean isHome = false;
    private boolean isProfile = false;

    private FirebaseAuth firebaseAuth;


                    /*Weather Code Starts Here*/

    Toolbar toolbar;
    WeatherApi weatherApi;
    TextView currentTempTV;
    public static int tempFormat = 1;
    public static int tabindex = 1;
    public static CurrentWeather weatherC;
    public static ForecastWeather weatherF;
    public static String location = "dhaka,bangladesh";
    String queryLocation = null;
    public static FragmentTransaction transactionDialog;
    MaterialSearchView searchView;
    String[] list;
    private TabLayout tabLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        firebaseAuth = FirebaseAuth.getInstance();

        toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        currentTempTV = findViewById(R.id.main_current_tempTV);
        currentTempTV.setVisibility(View.GONE);
        weatherApi = RetrofitClient.getRetrofitClient().create(WeatherApi.class);
        tabLayout = findViewById(R.id.main_tabs);
        tabLayout.addTab(tabLayout.newTab().setText("Current Weather"));
        tabLayout.addTab(tabLayout.newTab().setText("Forecast Weather"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        list = new String[]{"android", "dotnet", "java"};
        FragmentManager manager = getSupportFragmentManager();
        transactionDialog = manager.beginTransaction();
        callSearch();

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener()
        {
            @Override
            public void onTabSelected(TabLayout.Tab tab)
            {
                currentTempTV.setText(tab.getText().toString());
                if (tab.getPosition() == 0)
                {
                    tabindex = 1;
                    FragmentManager manager = getSupportFragmentManager();
                    FragmentTransaction transaction = manager.beginTransaction();
                    CurrentWeatherFragment fragment = new CurrentWeatherFragment();
                    transaction.replace(R.id.main_fragment_layout, fragment).commit();
                }
                else
                {
                    tabindex = 2;
                    FragmentManager manager = getSupportFragmentManager();
                    FragmentTransaction transaction = manager.beginTransaction();
                    ForecastWeatherFragment fragment = new ForecastWeatherFragment();
                    transaction.replace(R.id.main_fragment_layout, fragment).commit();
                }
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab)
            {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab)
            {
            }
        });
        callDefaultWeather();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater Inflater = getMenuInflater();
        Inflater.inflate(R.menu.menu_item, menu);

        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        MenuItem SignInItem = menu.findItem(R.id.item_login);
        MenuItem SignOutItem = menu.findItem(R.id.item_logout);
        MenuItem HomeItem = menu.findItem(R.id.item_home);
        MenuItem ProfileItem = menu.findItem(R.id.item_profile);

        SignOutItem.setVisible(true);
        SignInItem.setVisible(false);
        HomeItem.setVisible(true);
        ProfileItem.setVisible(true);

        return true;

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item_home:
                isHome = false;
                startActivity(new Intent(this, MainActivity.class));
                break;
            case R.id.item_profile:
                isProfile = false;
                startActivity(new Intent(this, ProfileActivity.class));
                break;
            case R.id.item_logout:
                firebaseAuth.signOut();
                finish();
                startActivity(new Intent(this, LoginActivity.class));
                break;
        }

        return super.onOptionsItemSelected(item);

    }


                        /*Weather Code Starts Here*/

    private void callDefaultWeather() {
        Call<CurrentWeather> weatherCall = weatherApi.getCurrentWeather(location, API_KEY);
        weatherCall.enqueue(new Callback<CurrentWeather>() {
            @Override
            public void onResponse(Call<CurrentWeather> call, Response<CurrentWeather> response) {
                CurrentWeather weather = response.body();
                if (weather != null) {
                    weatherC = weather;
                    if (tabindex == 1) {
                        FragmentManager manager = getSupportFragmentManager();
                        FragmentTransaction transaction = manager.beginTransaction();
                        CurrentWeatherFragment fragment = new CurrentWeatherFragment();
                        transaction.replace(R.id.main_fragment_layout, fragment).commit();
                    }
                } else {
                    location = queryLocation;
                    Toast.makeText(WeatherActivity.this, "Location Not Found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CurrentWeather> call, Throwable t) {

            }
        });
        Call<ForecastWeather> forecastWeatherCall = weatherApi.getForcastWeather(location, API_KEY);
        forecastWeatherCall.enqueue(new Callback<ForecastWeather>() {
            @Override
            public void onResponse(Call<ForecastWeather> call, Response<ForecastWeather> response) {
                ForecastWeather weather = response.body();
                if (weather != null) {
                    weatherF = weather;
                    if (tabindex == 2) {
                        FragmentManager manager = getSupportFragmentManager();
                        FragmentTransaction transaction = manager.beginTransaction();
                        ForecastWeatherFragment fragment = new ForecastWeatherFragment();
                        transaction.replace(R.id.main_fragment_layout, fragment).commit();
                    }
                } else {
                    location = queryLocation;
                    Toast.makeText(WeatherActivity.this, "Location Not Found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ForecastWeather> call, Throwable t) {
                //  Toast.makeText(getContext(),t.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void callSearch() {
        searchView = (MaterialSearchView) findViewById(R.id.main_search_view);
        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                queryLocation = location;
                location = query + ",bangladesh";
                callDefaultWeather();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchView.setSuggestions(getResources().getStringArray(R.array.query_suggestions));
                searchView.showSuggestions();
                return false;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.weather_action_home:
                return true;
            case R.id.weather_action_search:
                return true;
            case R.id.CelciousId:
                tempFormat = 1;
                callDefaultWeather();
                return true;
            case R.id.FarenhaitId:
                tempFormat = 2;
                callDefaultWeather();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.weather_menu, menu);
        MenuItem item = menu.findItem(R.id.weather_action_search);
        searchView.setMenuItem(item);

        return true;
    }
}
}
