package com.example.muhammad.easytour.Weather.Fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.muhammad.easytour.R;
import com.example.muhammad.easytour.Weather.Api.RetrofitClient;
import com.example.muhammad.easytour.Weather.Api.WeatherApi;
import com.example.muhammad.easytour.Weather.ForecastResponse.ForecastWeather;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

import static com.example.muhammad.easytour.MainActivity.tempFormat;
import static com.example.muhammad.easytour.MainActivity.weatherF;


public class ForecastWeatherFragment extends Fragment {
    TextView fForecastFirstDayMinTemp;
    TextView fForecastFirstDayDate;
    TextView fForecastFirstDayMaxTemp;

    TextView fForecastSecondDayMinTemp;
    TextView fForecastSecondDayDate;
    TextView fForecastSecondDayMaxTemp;

    TextView fForecastThirdDay;
    TextView fForecastThirdDayMinTemp;
    TextView fForecastThirdDayDate;
    TextView fForecastThirdDayMaxTemp;

    TextView fForecastFourthDay;
    TextView fForecastFourthDayMinTemp;
    TextView fForecastFourthDayDate;
    TextView fForecastFourthDayMaxTemp;

    TextView fForecastFifththDay;
    TextView fForecastFifthDayMinTemp;
    TextView fForecastFifthDayDate;
    TextView fForecastFifthDayMaxTemp;

    TextView locationTV;
    WeatherApi weatherApi;

    public ForecastWeatherFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_forecast_weather, container, false);


        locationTV = view.findViewById(R.id.fragment_forecast_locationTV);
        weatherApi = RetrofitClient.getRetrofitClient().create(WeatherApi.class);
        fForecastFirstDayMinTemp = view.findViewById(R.id.fragment_forecast_first_day_min_tempTV);
        fForecastFirstDayDate = view.findViewById(R.id.fragment_forecast_first_day_dateTV);
        fForecastFirstDayMaxTemp = view.findViewById(R.id.fragment_forecast_first_day_max_tempTV);
        fForecastSecondDayMinTemp = view.findViewById(R.id.fragment_forecast_second_day_min_tempTV);
        fForecastSecondDayDate = view.findViewById(R.id.fragment_forecast_second_day_dateTV);
        fForecastSecondDayMaxTemp = view.findViewById(R.id.fragment_forecast_second_day_max_tempTV);
        fForecastThirdDay = view.findViewById(R.id.fragment_forecast_third_day_nameTV);
        fForecastThirdDayMinTemp = view.findViewById(R.id.fragment_forecast_third_day_min_tempTV);
        fForecastThirdDayDate = view.findViewById(R.id.fragment_forecast_third_day_dateTV);
        fForecastThirdDayMaxTemp = view.findViewById(R.id.fragment_forecast_third_day_max_tempTV);
        fForecastFourthDay = view.findViewById(R.id.fragment_forecast_fourth_day_nameTV);
        fForecastFourthDayMinTemp = view.findViewById(R.id.fragment_forecast_fourth_day_min_tempTV);
        fForecastFourthDayDate = view.findViewById(R.id.fragment_forecast_fourth_day_dateTV);
        fForecastFourthDayMaxTemp = view.findViewById(R.id.fragment_forecast_fourth_day_max_tempTV);
        fForecastFifththDay = view.findViewById(R.id.fragment_forecast_fifth_day_nameTV);
        fForecastFifthDayMinTemp = view.findViewById(R.id.fragment_forecast_fifth_day_min_tempTV);
        fForecastFifthDayDate = view.findViewById(R.id.fragment_forecast_fifth_day_dateTV);
        fForecastFifthDayMaxTemp = view.findViewById(R.id.fragment_forecast_fifth_day_max_tempTV);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        setForecastTemp(weatherF);

    }

    private void setForecastTemp(ForecastWeather weather) {
        locationTV.setText(weather.getCity().getName());
        setToday(weather);
        setTomorrow(weather);
        setThirdDay(weather);
        setFourthDay(weather);
        setFifthDay(weather);

    }


    private void setFifthDay(ForecastWeather weather) {
        String temp = null, minTemp = null, maxTemp = null;
        String weekday_name = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(weather.getList().get(32).getDt().longValue() * 1000);
        if (tempFormat == 1) {

            minTemp = String.format("%.0f", weather.getList().get(32).getMain().getTempMinCentigrate()) + "\u2103";
            maxTemp = String.format("%.0f", weather.getList().get(32).getMain().getTempMaxCentigrate()) + "\u2103";
        }
        if (tempFormat == 2) {

            minTemp = String.format("%.0f", weather.getList().get(32).getMain().getTempMinFarenheit()) + "\u2109";
            maxTemp = String.format("%.0f", weather.getList().get(32).getMain().getTempMaxFarenheit()) + "\u2109";
        }
        fForecastFifthDayMaxTemp.setText(maxTemp);
        fForecastFifthDayMinTemp.setText(minTemp);

        String formattedDate = getDate(weather.getList().get(32).getDt().longValue() * 1000);
        fForecastFifthDayDate.setText(formattedDate);
        fForecastFifththDay.setText(weekday_name);
    }

    private void setFourthDay(ForecastWeather weather) {
        String temp = null, minTemp = null, maxTemp = null;
        String weekday_name = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(weather.getList().get(24).getDt().longValue() * 1000);
        if (tempFormat == 1) {

            minTemp = String.format("%.0f", weather.getList().get(24).getMain().getTempMinCentigrate()) + "\u2103";
            maxTemp = String.format("%.0f", weather.getList().get(24).getMain().getTempMaxCentigrate()) + "\u2103";
        }
        if (tempFormat == 2) {

            minTemp = String.format("%.0f", weather.getList().get(24).getMain().getTempMinFarenheit()) + "\u2109";
            maxTemp = String.format("%.0f", weather.getList().get(24).getMain().getTempMaxFarenheit()) + "\u2109";
        }
        fForecastFourthDayMaxTemp.setText(maxTemp);
        fForecastFourthDayMinTemp.setText(minTemp);

        String formattedDate = getDate(weather.getList().get(24).getDt().longValue() * 1000);
        fForecastFourthDayDate.setText(formattedDate);
        fForecastFourthDay.setText(weekday_name);
    }

    private void setThirdDay(ForecastWeather weather) {
        String temp = null, minTemp = null, maxTemp = null;
        String weekday_name = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(weather.getList().get(16).getDt().longValue() * 1000);
        if (tempFormat == 1) {

            minTemp = String.format("%.0f", weather.getList().get(16).getMain().getTempMinCentigrate()) + "\u2103";
            maxTemp = String.format("%.0f", weather.getList().get(16).getMain().getTempMaxCentigrate()) + "\u2103";
        }
        if (tempFormat == 2) {

            minTemp = String.format("%.0f", weather.getList().get(16).getMain().getTempMinFarenheit()) + "\u2109";
            maxTemp = String.format("%.0f", weather.getList().get(16).getMain().getTempMaxFarenheit()) + "\u2109";
        }
        fForecastThirdDayMaxTemp.setText(maxTemp);
        fForecastThirdDayMinTemp.setText(minTemp);
        // SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = getDate(weather.getList().get(16).getDt().longValue() * 1000);
        fForecastThirdDayDate.setText(formattedDate);
        fForecastThirdDay.setText(weekday_name);

    }

    private void setTomorrow(ForecastWeather weather) {
        String temp = null, minTemp = null, maxTemp = null;
        if (tempFormat == 1) {
            //temp=String.format("%.2f",weather.getList().get(0).getMain().getTempMCentigrate())+"\u2103";
            minTemp = String.format("%.0f", weather.getList().get(8).getMain().getTempMinCentigrate()) + "\u2103";
            maxTemp = String.format("%.0f", weather.getList().get(8).getMain().getTempMaxCentigrate()) + "\u2103";
        }
        if (tempFormat == 2) {
            //temp=String.format("%.2f",weather.getMain().getTempFahrenheit())+"\u2109";
            minTemp = String.format("%.0f", weather.getList().get(8).getMain().getTempMinFarenheit()) + "\u2109";
            maxTemp = String.format("%.0f", weather.getList().get(8).getMain().getTempMaxFarenheit()) + "\u2109";
        }
        fForecastSecondDayMaxTemp.setText(maxTemp);
        fForecastSecondDayMinTemp.setText(minTemp);
        // SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = getDate(weather.getList().get(8).getDt().longValue() * 1000);
        fForecastSecondDayDate.setText(formattedDate);
    }

    private String getDate(long time) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time);
        cal.setTimeZone(TimeZone.getTimeZone("GMT"));
        String date = DateFormat.format("dd-MMM-yyyy", cal).toString();
        return date;
    }

    private void setToday(ForecastWeather weather) {
        String temp = null, minTemp = null, maxTemp = null;
        String weekday_name = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(weather.getList().get(0).getDt().longValue() * 1000);
        if (tempFormat == 1) {
            minTemp = String.format("%.0f", weather.getList().get(0).getMain().getTempMinCentigrate()) + "\u2103";
            maxTemp = String.format("%.0f", weather.getList().get(0).getMain().getTempMaxCentigrate()) + "\u2103";
        }
        if (tempFormat == 2) {
            minTemp = String.format("%.0f", weather.getList().get(0).getMain().getTempMinFarenheit()) + "\u2109";
            maxTemp = String.format("%.0f", weather.getList().get(0).getMain().getTempMaxFarenheit()) + "\u2109";
        }

        fForecastFirstDayMaxTemp.setText(maxTemp);
        fForecastFirstDayMinTemp.setText(minTemp);
        String formattedDate = getDate(weather.getList().get(0).getDt().longValue() * 1000);
        fForecastFirstDayDate.setText(formattedDate);

    }
}
