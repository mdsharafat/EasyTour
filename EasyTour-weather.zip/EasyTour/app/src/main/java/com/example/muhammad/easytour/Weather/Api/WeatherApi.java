package com.example.muhammad.easytour.Weather.Api;

import com.example.muhammad.easytour.Weather.CurrentResponse.CurrentWeather;
import com.example.muhammad.easytour.Weather.ForecastResponse.ForecastWeather;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherApi {
    @GET("weather")
    Call<CurrentWeather> getCurrentWeather(@Query("q") String location, @Query("appid") String key);
    @GET("forecast")
    Call<ForecastWeather> getForcastWeather(@Query("q") String location, @Query("appid") String key);
}
