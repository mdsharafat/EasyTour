package com.example.muhammad.easytour.Weather.Fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.muhammad.easytour.R;
import com.example.muhammad.easytour.Weather.Api.RetrofitClient;
import com.example.muhammad.easytour.Weather.Api.WeatherApi;
import com.example.muhammad.easytour.Weather.CurrentResponse.CurrentWeather;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.muhammad.easytour.MainActivity.tempFormat;
import static com.example.muhammad.easytour.MainActivity.weatherC;


public class CurrentWeatherFragment extends Fragment {

    WeatherApi weatherApi;
    Calendar calender;
    ImageView fCurrentIcon;
    public static String API_KEY = "695ee37f478f85de2a301ff4eaee3fa6";
    TextView fCurrentTemp, fCurrentDate, fCurrentDay, fCurrentLocation, fCurrentMinTemp, fCurrentMaxTemp, fCurrentHumidity, fCurrentPressure, fCurrentSunrise, fCurrentSunset, fCurrentCondition, fCurrentDescription;


    public CurrentWeatherFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_current_weather, container, false);
        weatherApi = RetrofitClient.getRetrofitClient().create(WeatherApi.class);
        calender = Calendar.getInstance();
        fCurrentTemp = view.findViewById(R.id.fragment_current_temperatureTV);
        fCurrentDate = view.findViewById(R.id.fragment_current_dateTV);
        fCurrentDay = view.findViewById(R.id.fragment_current_dayTV);
        fCurrentMinTemp = view.findViewById(R.id.fragment_current_min_tempTV);
        fCurrentMaxTemp = view.findViewById(R.id.fragment_current_max_tempTV);
        fCurrentHumidity = view.findViewById(R.id.fragment_current_humidityTV);
        fCurrentPressure = view.findViewById(R.id.fragment_current_pressureTV);
        fCurrentSunrise = view.findViewById(R.id.fragment_current_sunriseTV);
        fCurrentSunset = view.findViewById(R.id.fragment_current_sunsetTV);
        fCurrentLocation = view.findViewById(R.id.fragment_current_locationTV);
        fCurrentCondition = view.findViewById(R.id.fragment_current_conditionTV);
        fCurrentDescription = view.findViewById(R.id.fragment_current_descriptionTV);
        fCurrentIcon = view.findViewById(R.id.fragment_current_weatherIV);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        setAll(weatherC);

    }

    private String getDate(long time) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time);
        String date = DateFormat.format("hh:mm a", cal).toString();
        return date;
    }

    public void setAll(CurrentWeather weather) {
        String temp = null, minTemp = null, maxTemp = null;
        if (tempFormat == 1) {
            temp = String.format("%.0f", weather.getMain().getTempCentigrate()) + "\u2103";
            minTemp = String.format("%.0f", weather.getMain().getTempMinCentigrate()) + "\u2103";
            maxTemp = String.format("%.0f", weather.getMain().getTempMaxCentigrate()) + "\u2103";
        }
        if (tempFormat == 2) {
            temp = String.format("%.0f", weather.getMain().getTempFahrenheit()) + "\u2109";
            minTemp = String.format("%.0f", weather.getMain().getTempMinFahrenheit()) + "\u2109";
            maxTemp = String.format("%.0f", weather.getMain().getTempMaxFahrenheit()) + "\u2109";
        }

        int tempInC = (int) (weather.getMain().getTemp() - 273);
        fCurrentCondition.setText(weather.getWeather().get(0).getDescription().toString());
        if(fCurrentCondition.getText().toString().contains("ain")){
            fCurrentIcon.setImageResource(R.drawable.rain_icon);
        }
        else if(fCurrentCondition.getText().toString().contains("aze")){
            fCurrentIcon.setImageResource(R.drawable.haze_icon);
        }
        else if(fCurrentCondition.getText().toString().contains("loud")){
            fCurrentIcon.setImageResource(R.drawable.cloud_icon);
        }
        else {
            fCurrentIcon.setImageResource(R.drawable.sunny);
        }
        fCurrentDescription.setText(weather.getWeather().get(0).getMain().toString());
        fCurrentLocation.setText(weather.getName().toString());
        fCurrentTemp.setText(temp);
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = df.format(c);
        fCurrentDate.setText(formattedDate);
        String weekday_name = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(System.currentTimeMillis());
        fCurrentDay.setText(weekday_name);
        fCurrentMinTemp.setText(minTemp);
        fCurrentMaxTemp.setText(maxTemp);
        fCurrentHumidity.setText("" + weather.getMain().getHumidity() + "%");
        fCurrentPressure.setText("" + weather.getMain().getPressure() + "hpa");

        fCurrentSunrise.setText(getDate(weather.getSys().getSunrise().longValue() * 1000));
        fCurrentSunset.setText(getDate(weather.getSys().getSunset().longValue() * 1000));
    }

    private void setTemp(String location) {


        Call<CurrentWeather> weatherCall = weatherApi.getCurrentWeather(location, API_KEY);
        weatherCall.enqueue(new Callback<CurrentWeather>() {
            @Override
            public void onResponse(Call<CurrentWeather> call, Response<CurrentWeather> response) {
                CurrentWeather weather = response.body();
                weatherC = weather;
                setAll(weatherC);
                //currentTempTV.setText(weather.getMain().getTemp().toString());
                // http://api.openweathermap.org/data/2.5/forecast?q=dhaka,bangladesh&appid=b2ed8cc71534bb766df35dbf3bbc0056
            }

            @Override
            public void onFailure(Call<CurrentWeather> call, Throwable t) {

            }
        });
    }
}
